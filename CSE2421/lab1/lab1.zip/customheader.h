/*Naishal Patel*/
#define INIT 1
